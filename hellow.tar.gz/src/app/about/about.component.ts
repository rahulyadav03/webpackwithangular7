import {Component} from "@angular/core";
import '../../style.css';

@Component({
    selector: "about-app",	
    styleUrls: [String(require("./about.component.scss"))],
    template: require("./about.component.html"),
})
export class AboutComponent {
	
}