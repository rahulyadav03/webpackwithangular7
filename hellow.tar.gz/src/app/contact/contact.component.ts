import {Component} from "@angular/core";
import '../../style.css';

@Component({
    selector: "contact-app",	
    styleUrls: [String(require("./contact.component.scss"))],
    template: require("./contact.component.html"),
})
export class ContactComponent {
	
}