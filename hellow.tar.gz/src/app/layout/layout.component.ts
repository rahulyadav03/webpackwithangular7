import { Component, OnInit } from '@angular/core';

@Component({
	selector: "layout-app",	
    styleUrls: [String(require("./layout.component.scss"))],
    template: require("./layout.component.html"),
})

export class LayoutComponent implements OnInit {
	
	constructor() { }

	ngOnInit() {
	
	}
}